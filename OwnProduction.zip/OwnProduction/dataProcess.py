import numpy as np
from config import pca_base_x, pca_base_y
from model import pca, compute_alpha_beta

# X = np.random.rand(60, 1280 * 3)
# Y = np.random.rand(60, 6)
# np.save("data/test_X.npy", X)
# np.save("data/test_Y.npy", Y)
# print(X.shape)
# print(Y.shape)

print("Loading data X, Y")
# sim data load in numpy array for network training，numpy loads X，Y
X = np.load("data/test_X.npy")
Y = np.load("data/test_Y.npy")
# x.shape = (n, 3c)   y.shape = (n, 3)
(dim_row_x, dim_col_x) = X.shape
(dim_row_y, dim_col_y) = Y.shape
# neural network parameters include：Z，W. we know:  Z = U * (X-Xu) , W = V * (Y - Yu),
# U.shape = (pca_base_x, dim_row_shape_x) V.shape = (pca_base_y, dim_row_shape_y)
print("Done! pre Processing X,Y,Z,W ......")
(Z, U, x_mean) = pca(X, pca_base_x)  # Z shape is PCA_base_x_dim , dim_col_x
(W, V, y_mean) = pca(Y, pca_base_y)  # W shape is PCA_base_y_dim , dim_col_y
# 注意U要在以后恢复X使用  Z*U^T = x*   =  (x* - x_mean*)

print(f"X.shape: {X.shape}")
print(f"Y.shape: {Y.shape}")
print(f"Z.shape: {Z.shape}")
print(f"W.shape: {W.shape}")
# 使用训练数据的z和w计算


# 阅读论文: z_t = alpha (*) z_t-1  + beta (*) z_t-2 计算方法
alpha, beta = compute_alpha_beta(Z, pca_base_x)

# np.save("alpha_num.npy", alpha)
# np.save("bela_num.npy", beta)
(dim_row_z, dim_col_z) = Z.shape
z_init = np.zeros((dim_row_z-2, dim_col_z))  # init expect_z except z0 ,z1

for i in range(2, dim_row_z):
    # numpy automately execute component-wise mul
    z_init[i-2, :] = alpha * Z[i-1, :] + beta * (Z[i-1, :] - Z[i-2, :])


# our goal is to predict delta_z from 2->s , # Update network parameters theta





