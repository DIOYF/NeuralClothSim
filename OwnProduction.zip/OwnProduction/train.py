import numpy as np
import torch
import torch.nn as nn
from torch.utils.tensorboard import SummaryWriter
from config import epochs, batch_size, windows_size, delta_t, train_ratio
from config import pca_base_x, pca_base_y
from config import learning_rate, decay_ratio
from datetime import datetime
from model import PhiNet
from dataProcess import Z, W, z_init, alpha, beta
from dataProcess import dim_row_x, dim_col_x, dim_row_y, dim_col_y, dim_row_z, dim_col_z

print("dataLoad Done!")
# 根据论文公式Z_t - z_init_t = PHI([Z_init_t, z_t-1, w_t]^T)
# 输入网络的参数包括[Z_t-1, W_t, Z_init_t] ,  输出网络的参数为: z_t - Z_init
network_input = np.hstack(
        (
            z_init,  # z2, z3, z4, ... zn  cst z_init_t
            Z[1: dim_row_z-1, :],  # z1,z2, .... zn-1  cst  z_t-1
            W[2: dim_row_z, :]  # w2,w3,w4, ... cst w_t
            # predict z_t using z_t-1 and w_t
        )
    )

network_output = Z[2:dim_row_z, :] - z_init  # 用于计算loss, 由于损失使用1范数，所以该值为L_pos的初始值

# 网络的输入输出
model = PhiNet(pca_base_x, pca_base_x * 2 + pca_base_y)
params = model.parameters()
# 文中使用的优化器是AmsGrad, 如果效果不好amsgrad设置为false
optimizer = torch.optim.Adam(params, lr=learning_rate, betas=decay_ratio, amsgrad=True)


# loss_function
def loss(predict, last_predict, truth, last_truth):
    loss_fn = nn.L1Loss()
    pos_loss = loss_fn(truth, predict)

    vel_predict = (predict - last_predict) / delta_t
    vel_truth = (truth - last_truth) / delta_t
    vel_loss = loss_fn(vel_truth, vel_predict)
    return pos_loss + vel_loss


# 窗口设计和batch设计
# num_window = window_size -2

def construct_sample(input_z, input_w, idx):
    (input_z_row, input_z_col) = input_z.shape
    (input_w_row, input_w_col) = input_w.shape
    if idx + 2 >= input_z_row:
        return np.array([]), np.array([]), np.array([]), np.array([])

    z0 = input_z[idx, :]  # z0, z1 是不包含在z_init里的，所以需要生成两个采样值z_init_one, z_init_two
    z1 = input_z[idx+1, :]
    noise0 = np.random.normal(0, 0.01, input_z_col)  # z_init的维度
    noise1 = np.random.normal(0, 0.01, input_z_col)

    z0 = z0 + noise0   # z0 denotes z0_init  随机采样的帧
    z1 = z1 + noise1  # z1 denotes z1_init 随机采样的帧

    dim_window = min(windows_size, input_z_row - idx - 1)  # 窗口大小
    z_window_input = np.zeros((dim_window-2, input_z_col*2 + input_w_col))  # 输入网络的参数size
    z_window_predict = np.zeros((dim_window-2, input_z_col))

    # 在窗口内循环预测，初始化，并且将第一次预测的结构构建为windows batch
    # algorithm 的 predict部分
    for k in range(2, dim_window):
        z_init = alpha * z1 + beta * (z1 - z0)
        input_data = np.hstack((z_init, z1, input_w[idx+k, :]))
        input_batch1 = np.array([input_data], dtype=np.float32)
        model.eval()
        with torch.no_grad():
            result = model(torch.from_numpy(input_batch1).float())
            predict = z_init + result.numpy()[0, :]

        z_window_input[k-2, :] = input_data
        z_window_predict[k-2, :] = predict
        z0 = z1
        z1 = predict

    z_window_truth = input_z[idx+2:idx+dim_window, :]
    (z_window_rows, z_window_cols) = z_window_truth.shape

    z_window_last_truth = np.vstack(
        (
            input_z[idx+1, :],
            z_window_truth[0:z_window_rows-1, :]
        )
    )

    z_window_last_predict = np.vstack(
        (
            z1,
            z_window_predict[0:z_window_rows-1, :]
        )
    )
    return z_window_input, z_window_truth, z_window_last_truth, z_window_last_predict


# how to construct batch: to read paper
def construct_batch(z_ipnut, w_input, start, end):
    batch_input = np.array([])
    output_truth = np.array([])
    last_truth = np.array([])
    last_predict = np.array([])
    for j in range(start, end):
        if j == start:
            batch_input, output_truth, last_truth, last_predict = construct_sample(z_ipnut, w_input, j)
        else:
            tem_input, tem_truth, tem_last_truth, tem_last_predict = construct_sample(z_ipnut, w_input, j)
            if tem_input.size:
                batch_input = np.vstack((batch_input, tem_input))
                output_truth = np.vstack((output_truth, tem_truth))
                last_truth = np.vstack((last_truth, tem_last_truth))
                last_predict = np.vstack((last_predict, tem_last_predict))

    # 构建batch_size：使用不同的Windows构建
    return batch_input, output_truth, last_truth, last_predict


(all_z_row, all_z_col) = Z.shape
num_z_train = int(all_z_row * train_ratio)
z_train = Z[0: num_z_train, :]
z_test = Z[num_z_train, :]
w_train = W[0: num_z_train, :]
w_test = W[num_z_train:, :]

(z_rows, z_cols) = z_train.shape

log_dir = "./logs"
with SummaryWriter(log_dir) as writter:
    for epoch in range(epochs):
        print("Start of epoch %d" % (epoch,))
        step = 0
        for i in range(0, z_rows, batch_size):
            if i + batch_size > z_rows:
                break

            batch_start = i
            batch_end = min(batch_start +batch_size, z_rows)
            step += 1
            input_batch, batch_truch, batch_last_truch, batch_last_predict = construct_batch(z_train, w_train, batch_start, batch_end)
            model.train()
            optimizer.zero_grad()
            batch_prediction = model(torch.from_numpy(input_batch).float())
            batch_loss = loss(batch_prediction, torch.from_numpy(batch_last_predict).float(), torch.from_numpy(batch_truch).float(), torch.from_numpy(batch_last_truch).float())
            batch_loss.backward()
            optimizer.step()

            if True: # step % 100 == 0:
                print("Training loss (for one batch) at step %s: %s " % (epoch*epochs+step, float(batch_loss)))


savetime = datetime.now()
strtime = "day" + str(savetime.day)+ "hour" + str(savetime.hour)+"minute"+str(savetime.minute)
torch.save(model.state_dict(), f'saveModel/model{strtime}.pt')



# 在渲染环境中实现：
# For the cape and skirt results, we implement a basic character
# controller using Motion Matching [Clavet 2016] and allow the user
# to dynamically control the character with a gamepad. The data we
# use in the motion matching includes motion clips that were present
# in the training data. Most other user interaction is simply enabled
# by allowing the user to manipulate the interaction object(s) with a
# mouse, or sliders on the user interface.

# 优化：向GPU传输的是压缩过的渲染数据。
