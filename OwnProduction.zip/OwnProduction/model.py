import torch
import numpy as np
import scipy
from torch import nn
# cuda test
# if torch.cuda.is_available() == False:
#     print("no cuda device")
# try:
#     a = torch.tensor([1, 2]).cuda()
# except:
#     print("cuda Wrong")
# =========================
# PCA
def pca(X, pca_base):
    """
    :param X: Input Data as model framework
    :param pca_base: pca_base_dim
    :return: Z = U(X - x_mean), returan Z,U,x_mean
    """
    (row, col) = X.shape
    x_mean_scaler = np.mean(X, axis=0)
    X_mean = np.tile(x_mean_scaler, (row, 1))
    center_matrix = X - X_mean
    cov_data = np.cov(center_matrix.T)  # 协方差矩阵
    (eigens, vec) = np.linalg.eig(cov_data)  # 协方差矩阵特征值，特征向量
    sorted_indices = np.argsort(eigens)  # np.argsort()
    U = top_k_vec = vec[:, sorted_indices[: -pca_base-1: -1]] # 对返回的向量按照特征值大小排序
    Z = np.matmul(center_matrix, top_k_vec)

    return Z, U, x_mean_scaler


def compute_alpha_beta(Z, pca_base_x):
    alpha = np.zeros(pca_base_x)  # base_x_dim data
    beta = np.zeros(pca_base_x)  # base_x_dim data
    # these alpha, beta compute can be optimized
    # z_t = alpha * z_t-1 + beta * (z_t-1 - z_t-2), alpha , bela is compute for model train
    # construct Ax = B and || b - Ax || ^ 2 , using linear least squares compute alpha , beta
    for i in range(0, pca_base_x):
        # i denotes pca_dim id which means compute alpha_i
        (rows, cols) = Z.shape  # frames * pca_dim   (最小二乘法计算alpha,beta)

        col_Z_i = Z[:, i]
        # construct A * [alpha_m,beta_m] = b
        b = col_Z_i[2: rows]
        A = np.zeros([rows-2, 2])

        A[:, 0] = col_Z_i[1:rows-1]
        for j in range(1, rows-1):
            A[j-1, 1] = col_Z_i[j] - col_Z_i[j-1]


        res = np.linalg.lstsq(A, b, rcond=None)
        alpha[i], beta[i] = res[0][0], res[0][1]
    # using linear least square method to compute alpha and beta
    return alpha, beta


class PhiNet(nn.Module):
    def __init__(self, dim_pca_x, input_shape):
        super().__init__()
        hidden_dim = int(1.5 * dim_pca_x) # we set hidden layer dimmension with 1.5 * num_pca_x
        self.mlp = nn.Sequential(
            nn.Linear(input_shape, hidden_dim), nn.ReLU(),

            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),

            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),

            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),

            nn.Linear(hidden_dim, dim_pca_x)
        )

    def forward(self, x):
        num_pca_x = self.mlp(x)
        return num_pca_x


# loss
# optimizer

