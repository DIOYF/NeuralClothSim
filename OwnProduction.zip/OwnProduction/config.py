import os

batch_size = 16
overlapping_windows = 32
epochs = 1000
learning_rate = 0.0001  # learning rate
decay_ratio = (0.9, 0.999)  # learning rate decay ratio
r_sigma = 0.01  # noise standard deviation
pca_base_x = 256  # choose from [256, 64128 64, 128]
pca_base_y = 3

windows_size = 3  # windows_size must > 2
delta_t =  1  #
train_ratio = 0.8


