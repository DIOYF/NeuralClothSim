import numpy as np
from datetime import datetime
savetime = datetime.now()
print()

## 每一行减去对应的均值
X = np.array([
    [1, 2, 3],
    [1, 2, 3],
    [1, 2, 5],
    [1, 3, 5],
    [1, 3, 4]
])  # X 是5 * 3 矩阵， 表示R 3c * n 要对每一列进行均值特化

a1 = np.mean(X, axis=0)  # 每一行减去该行均值
a = np.tile(a1,  (X.shape[0], 1) )

print(X.shape)   # 5行4列，X对应行号
print(a)


def pca(X, pca_base):
    """
    :param X: Input Data as model framework
    :param pca_base: pca_base_dim
    :return: Z = U(X - x_mean), returan Z,U,x_mean
    """
    (row, col) = X.shape
    x_mean_scaler = np.mean(X, axis=0)
    X_mean = np.tile(x_mean_scaler, (row, 1))
    center_matrix = X - X_mean
    cov_data = np.cov(center_matrix.T)  # 协方差矩阵
    (eigens, vec) = np.linalg.eig(cov_data)  # 协方差矩阵特征值，特征向量
    sorted_indices = np.argsort(eigens)  # np.argsort()
    U = top_k_vec = vec[:, sorted_indices[: -pca_base - 1: -1]]  # 对返回的向量按照特征值大小排序
    Z = np.matmul(center_matrix, top_k_vec)

    return Z, U, x_mean_scaler


print("PCA results:" )
dim = 2

(Z, U, x) = pca(X,2)
# PCA主成分分析
print("Z" ,Z)
print("U:",U)
print("X:",x)


alpha = np.zeros(dim)
beta = np.zeros(dim)

for i in range(0, dim):
    (rows, cols) = Z.shape
    cur_z = Z[:, i]
    b = cur_z[2:rows]
    A = np.zeros([rows-2, 2])
    A[:, 0] = cur_z[1:rows-1]

    for j in range(1, rows-1):
        A[j-1, 1] = cur_z[j] - cur_z[j-1]

    res = np.linalg.lstsq(A, b, rcond=None)
    alpha[i] = res[0][0]
    beta[i] = res[0][1]

print("alpha:", alpha)
print("belta", beta)
